#ifndef PDESOLVER_HPP
#define PDESOLVER_HPP

#include "tov.hpp"
#include <libInterpolate/Interpolate.hpp>
#include <fstream>
#include <thread>

class PDEsolver
{
    private :
        std::vector<double> r_inside;
        std::vector<double> z_inside;
        matrix sourcePsi, dXdRho, dXdZ, dPsidRho, dPsidZ;
    public:

        /*
        grid properties
        0 <= rho <= R
        0 <= z <= R
        dx : resolution
        size NxN
        */
        double R, dx;
        array r, z;
        const size_t N;

        //system state matrixes
        matrix U, Psi, H;

        //magnetic field related matrixes
        matrix J,  Br, Bz;

        //fluid related matrixes
        matrix En, Mag, Pr;    

        //EoS interpolators
        function2D E, M, P;

        //current function
        const double f0;

        PDEsolver(const TOVsolution & tov_guess, const size_t NN,const double f, 
            const function2D & Eint, const function2D & Pint,const function2D & Mint
        );

        //get observables
        inline double get_mass() const ;
        inline double get_quadrupolar_mass_moment() const;
        inline double get_magnetic_energy() const;
        inline double get_pressure_ratio() const;
        inline double get_central_mf() const;
        inline double get_polar_mf() const;
        inline double get_equatorial_radius() const;
        inline double get_polar_radius() const;

        void update_B();
        void update_J();
        void update_M();
        void update_P();
        void update_E();

        
        void update_exterior_boundary();
        double update_gs(double Hc);
        void solve(double Hc);

        
        
        

        

        

        


        
       

        

        
};

























#endif