#ifndef NUMERICS_HPP

#define  NUMERICS_HPP

#include <functional>
#include <boost/math/quadrature/gauss_kronrod.hpp>
#include <boost/math/special_functions/hypergeometric_pFq.hpp>
#include <Eigen/Dense>


using function1D = std::function<double(double)>;
using function2D = std::function<double(double,double)>;
using array = Eigen::ArrayXd;
using matrix = Eigen::ArrayXXd;


constexpr double pi = 3.141516;
constexpr double MSg = 1.989e+33;  //masa del Sol en gramos
constexpr double R0 = 1.477; // G*MS en km
constexpr double MS = 1.1158e+60; //Masa del Sol en MeV
constexpr double G = 6.711e-45;//MeV^-2
constexpr double Mev = 1/(5.07e+9);//km
constexpr double km = 5.07e+15;


namespace numerics {

    inline double LegendreP2(double x)
    {
        return 3 * x * x / 2 - 0.5;
    }

    inline double Qm12(double chi)
    {
        return pi / sqrt(2 * chi) * boost::math::hypergeometric_pFq({0.75,0.25}, {1.0}, 1/(chi*chi));
    }

    double integrate(const function2D & f1, double xmin, double xmax, double ymin, double ymax)
    {
        auto f = [&](double t) {
            auto g = [&](double s) {
                return f1(t, s);
            };
            return boost::math::quadrature::gauss_kronrod<double, 61>::integrate(g, ymin, ymax);
        };
        double Q = boost::math::quadrature::gauss_kronrod<double, 15>::integrate(f, xmin, xmax);
        return Q;
    }

    void gradientX(const matrix & M, matrix &dest, const double dx)  
    {
        const size_t Nx = M.rows();
        const size_t Ny = M.cols();

        //Compute D_x
        for (size_t i = 1; i < Nx - 1; i++)
        {
            for (size_t j = 0; j < Ny; j++)
            {
                dest(i,j) = (M(i+1,j) - M(i-1,j))/ ( 2 * dx);
            }
        }
        //Compute left and rigth
        for (size_t j = 0; j < Ny; j++)
        {
            dest(0,j) = 0;
            dest(Nx - 1,j) = (M(Nx - 1,j) - M(Nx-2,j))/ (dx);
        }
    };

    void gradientY(const matrix & M, matrix &dest, const double dx)
    {
        const size_t Nx = M.rows();
        const size_t Ny = M.cols();

        //Compute D_x
        for (size_t j = 1; j < Ny - 1; j++)
        {
            for (size_t i = 0; i < Nx; i++)
            {
                dest(i,j) = (M(i,j+1) - M(i,j-1))/ ( 2 * dx);
            }
        }
        //Compute left and rigth
        for (size_t i = 0; i < Nx; i++)
        {
            dest(i,0) = (M(i,1) - M(i,0))/dx;
            dest(i,Ny-1) = (M(i,Ny-1) - M(i,Ny-2))/ (dx);
        }
    };

}


#endif