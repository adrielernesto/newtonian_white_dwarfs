#include <PDEsolver.hpp>

double PDEsolver::update_gs(double Hc)
{
    //std::cout << "f0 in gs = " << f0 << std::endl;
    update_B();
    update_E();
    update_P();
    update_M();
    update_J();

    numerics::gradientX(Psi,dPsidRho,dx);
    numerics::gradientY(Psi,dPsidZ,dx);

    numerics::gradientX(Mag,dXdRho,dx);
    numerics::gradientY(Mag,dXdZ,dx);

    

    for (size_t i = 0; i < N; i++)
        for (size_t j = 0; j < N; j++)
            sourcePsi(i,j) = - 4 * pi * r(i)*r(i) * J(i,j)/(1-Mag(i,j)) - Bz(i,j) 
                -  ( dXdRho(i,j)*dPsidRho(i,j) + dXdZ(i,j)*dPsidZ(i,j))/(1-Mag(i,j));
    
    
    double oldU = U(0, 0);
    double oldPsi = Psi(0, 0);



    
    
    //update_exterior_boundary();

    //Update z axis
    for (size_t j = 1; j  < N - 1; j++)
    {
        U(0,j) = - dx*dx/4 * (4 * pi * G * En(0,j)) + 
                        0.25 * (2 * U(1,j) + U(0,j + 1) + U(0, j -1));
        //Psi(0,j) = - dx*dx/4 * ( -  Bz(0,j)) + 
        //                0.25 * (2 * Psi(1,j) + Psi(0,j + 1) + Psi(0, j -1));
    }
   
    //Update interior
    for ( size_t i = 1; i < N - 1; i++)
    {
        for (size_t j = 1; j  < N - 1; j++)
        {
            U(i,j) = - dx*dx/4 * (4 * pi * G * En(i,j)) + dx / (8 * r(i)) * (U(i+1,j) - U(i-1,j)) +
                        0.25 * (U(i,j+1) + U(i,j-1) + U(i-1,j) + U(i+1,j));
            Psi(i,j) = - dx*dx/4 * ( sourcePsi(i,j) ) +
                        0.25 * (Psi(i,j+1) + Psi(i,j-1) + Psi(i-1,j) + Psi(i+1,j));
        }
    }
     
    //Update bottom
    for (size_t i = 1; i  < N - 1; i++)
    {
        U(i,0) = - dx*dx/4 * (4 * pi * G * En(i,0)) + dx / (8 * r(i)) * (U(i+1,0) - U(i-1,0)) +
                        0.25 * (2 * U(i,1) + U(i+1,0) + U(i-1,0));
        Psi(i,0) = - dx*dx/4 * ( sourcePsi(i,0)) + 
                        0.25 * (2 * Psi(i,1) + Psi(i+1,0) + Psi(i-1,0));
    }
 
    //update centre
    U(0,0) = - dx*dx/4 * (4 * pi * G * En(0,0)) + 0.25 * (2 * U(0,1) + 2 * U(1,0));
    
    H = - U + f0 * Psi + Hc + U(0,0) - f0 * Psi(0,0);
    
    
    

    

    double errU = std::abs( (oldU - U(0, 0))/oldU);
    double errPsi = 0 ; //std::abs( (oldPsi - Psi(0, 0))/oldPsi);
    return  sqrt(errU*errU + errPsi*errPsi) ;

}