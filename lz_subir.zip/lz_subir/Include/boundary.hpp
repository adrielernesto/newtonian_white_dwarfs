#include <PDEsolver.hpp>


void PDEsolver::update_exterior_boundary()
{
    /*
    double mass = get_mass();
    for (size_t i = 0; i < N; i++)   U(i,N-1) = - G * mass / sqrt(r(i) * r(i) + z(N-1)*z(N-1));
    for (size_t i = 0; i < N; i++)   U(i,0) = - G * mass / sqrt(r(i) * r(i) + z(0)*z(0));
    for (size_t j = 1; j < N - 1; j++) U(N-1,j) = - G * mass / sqrt(r(N-1) * r(N-1) + z(j)*z(j));   
    */

    
    //std::cout << integrandU.size() << std::endl;
    double Z;
    
    //Update Upper Boudary
    std::cout << "Upper" << std::endl;
    
    Z = z(N-1);
    
    
    #pragma omp parallel for  schedule(static,1)
    for (size_t k = 1; k < N; k++)
    {    
        std::vector<double> integrandU( (N - 2) * (N - 2) );
        std::vector<double> integrandPsi( (N - 2) * (N - 2) );
        //std::cout << k << std::endl;
        double Rho = r(k);
        double chi, q1, q2;
        _2D::BicubicInterpolator<double> f, g;
        //std::cout << Rho << std::endl;
        
        for (size_t i = 1; i < N - 1; i++)
        {
            for (size_t j = 1; j < N - 1; j++)
            {
                double sourcePsi = - 4 * pi * J(i,j) * r(i) * r(i) - 2 * Bz(i,j);
                chi = (Rho * Rho + r(i)*r(i) + (Z-z(j)) * (Z-z(j)) ) / (2 * Rho * r(i));
                integrandU[(i-1) * (N - 2) + (j-1)] = sqrt(r(i)) * En(i,j) * numerics::Qm12(chi);
                integrandPsi[(i-1) * (N - 2) + (j-1)] = sqrt(r(i)) *( sourcePsi -2* Bz(i,j) ) * numerics::Qm12(chi);
                //std::cout << chi << std::endl;
            }
        }
        f.setData(r_inside,z_inside,integrandU);
        g.setData(r_inside,z_inside,integrandPsi);
        q1 = numerics::integrate(f,r(1),r(N-2), z(1), z(N-2));
        q2 = numerics::integrate(g,r(1),r(N-2), z(1), z(N-2));
        U(k,N-1) = U(0,N-1)  = - 2 * G / sqrt(Rho) * q1;
        Psi(k,N-1) = Psi(0,N-1) = - 1 /(2 * pi * sqrt(Rho)) * q2;
    }


    //std::cout << "Lower" << std::endl;
    /*
    Z = z(0);
    
    
    #pragma omp parallel for  schedule(static,1)
    for (size_t k = 1; k < N; k++)
    {    
        std::vector<double> integrandU( (N - 2) * (N - 2) );
        std::vector<double> integrandPsi( (N - 2) * (N - 2) );
        //std::cout << k << std::endl;
        double Rho = r(k);
        double chi, q1, q2;
        _2D::BicubicInterpolator<double> f, g;
        //std::cout << Rho << std::endl;
        
        for (size_t i = 1; i < N - 1; i++)
        {
            for (size_t j = 1; j < N - 1; j++)
            {
                double sourcePsi = - 4 * pi * J(i,j) * r(i) * r(i) - 2 * Bz(i,j);
                chi = (Rho * Rho + r(i)*r(i) + (Z-z(j)) * (Z-z(j)) ) / (2 * Rho * r(i));
                integrandU[(i-1) * (N - 2) + (j-1)] = sqrt(r(i)) * En(i,j) * numerics::Qm12(chi);
                integrandPsi[(i-1) * (N - 2) + (j-1)] = sqrt(r(i)) * sourcePsi * numerics::Qm12(chi);
                //std::cout << chi << std::endl;
            }
        }
        f.setData(r_inside,z_inside,integrandU);
        g.setData(r_inside,z_inside,integrandPsi);
        q1 = numerics::integrate(f,r(1),r(N-2), z(1), z(N-2));
        q2 = numerics::integrate(g,r(1),r(N-2), z(1), z(N-2));
        U(k,0) = - 2 * G / sqrt(Rho) * q1;
        Psi(k,0)  =  -1 /(2 * pi * sqrt(Rho)) * q2;
    }

    */

    U(0,0) = U(1,0);
    U(0,N-1) = U(1,N-1);

    
    //std::cout << std::endl;

    std::cout << "Rigth" << std::endl;
    double Rho = r(N-1);
    #pragma omp parallel for schedule(static,1)
    for (size_t k = 1; k < N - 1; k++)
    {    
        std::vector<double> integrandU( (N - 2) * (N - 2) );
        std::vector<double> integrandPsi( (N - 2) * (N - 2) );
        //std::cout << k << std::endl;
        double Z = z(k);
        double chi, q1, q2;
        _2D::BicubicInterpolator<double> f, g;
        //std::cout << Rho << std::endl;
        
        for (size_t i = 1; i < N - 1; i++)
        {
            for (size_t j = 1; j < N - 1; j++)
            {
                double sourcePsi = - 4 * pi * J(i,j) * r(i) * r(i) - 2 * Bz(i,j);
                chi = (Rho * Rho + r(i)*r(i) + (Z-z(j)) * (Z-z(j)) ) / (2 * Rho * r(i));
                integrandU[(i-1) * (N - 2) + (j-1)] = sqrt(r(i)) * En(i,j) * numerics::Qm12(chi);   
                integrandPsi[(i-1) * (N - 2) + (j-1)] =  sqrt(r(i)) * sourcePsi * numerics::Qm12(chi);
                //std::cout << chi << std::endl;
            }
        }
        f.setData(r_inside,z_inside,integrandU);
        g.setData(r_inside,z_inside,integrandPsi);
        q1 = numerics::integrate(f,r(1),r(N-2), z(1), z(N-2));
        q2 = numerics::integrate(g,r(1),r(N-2), z(1), z(N-2));
        U(N-1,k) =  - 2 * G / sqrt(Rho) * q1;
        Psi(N-1,k) = - 1 /(2 * pi * sqrt(Rho)) * q2;
    }
    
}
