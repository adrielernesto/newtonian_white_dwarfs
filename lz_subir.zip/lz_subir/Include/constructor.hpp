#include <PDEsolver.hpp>

PDEsolver::PDEsolver(
    const TOVsolution & tov_guess, const size_t NN, double f, 
    const function2D & Eint, const function2D & Pint,const function2D & Mint
    )   : N(NN), E(Eint) , P(Pint), M(Mint), f0(f)
{
    std::cout << "f0= " << f0 << std::endl;
    R = tov_guess.StarRadius > 5 * km ?  3 * tov_guess.StarRadius : 4000 * km;
    U = Eigen::ArrayXXd::Zero(N,N);
    H = Eigen::ArrayXXd::Zero(N,N);
    En = Eigen::ArrayXXd::Zero(N,N);
    Br = Eigen::ArrayXXd::Zero(N,N);
    Bz = Eigen::ArrayXXd::Zero(N,N);
    J = Eigen::ArrayXXd::Zero(N,N);
    Mag = Eigen::ArrayXXd::Zero(N,N);
    Psi = Eigen::ArrayXXd::Zero(N,N);
    Pr = Eigen::ArrayXXd::Zero(N,N);
    sourcePsi = Eigen::ArrayXXd::Zero(N,N); 
    dXdRho= Eigen::ArrayXXd::Zero(N,N); dXdZ= Eigen::ArrayXXd::Zero(N,N);
    dPsidRho= Eigen::ArrayXXd::Zero(N,N); dPsidZ= Eigen::ArrayXXd::Zero(N,N);

    r =  Eigen::ArrayXd::LinSpaced(N,0, R);
    z =  Eigen::ArrayXd::LinSpaced(N, 0, R);
    dx =  R / (N - 1);

    for (size_t i = 0; i < N; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            double d = sqrt(r(i) * r(i) + z(j) * z(j));
            if (d < tov_guess.StarRadius)
            {
                double energy = E(tov_guess.H_vs_r(d),0);
                U(i,j) = tov_guess.U_vs_r(d);
                H(i,j) = tov_guess.H_vs_r(d);
                En(i,j) = energy;
                J(i,j) = f0 * (Pr(i,j) + En(i,j));
                Psi(i,j) = 0;
            }
            else 
            {
                U(i,j) = - G * tov_guess.StarMass/ d ;
                H(i,j) = En(i,j) = 0;
                Psi(i,j) = 0;
            }
        }
    }


    for (size_t i = 1; i < N - 1; i++)
    {
        for (size_t j = 1; j < N - 1; j++)
        {
            r_inside.push_back(r(i));
            z_inside.push_back(z(j));
        }
    }
    //std::cout << r_inside.size() << std::endl;
    //std::cout << z_inside.size() << std::endl;

    std::ofstream file;
    file.open(".//out//r.dat");
    file << r/km;
    file.close();
    file.open(".//out//z.dat");
    file << z/km;
    file.close();
}