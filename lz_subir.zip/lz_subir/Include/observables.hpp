#include <PDEsolver.hpp>

double PDEsolver::get_mass() const 
{
    std::vector<double> x(N*N), y(N*N), val(N*N);
    #pragma omp parallel for
    for (size_t i = 0; i < N; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            x[i*N + j] = r(i);
            y[i*N + j] = z(j);
            val[i*N + j] =  r(i) * ( En(i,j)  );
        }
    }
    _2D::BicubicInterpolator<double> fu;
    fu.setData(x,y,val);

    return 4 * pi * numerics::integrate(fu, 0, R, 0, R);
}

double PDEsolver::get_magnetic_energy() const
{
    std::vector<double> x(N*N), y(N*N), val(N*N);
    //#pragma omp parallel for
    for (size_t i = 0; i < N; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            x[i*N + j] = r(i);
            y[i*N + j] = z(j);
            val[i*N + j] =  r(i) * ( 1/(8*pi)*(Bz(i,j)*Bz(i,j) + Br(i,j)*Br(i,j))   );
        }
    }
    _2D::BicubicInterpolator<double> fu;
    fu.setData(x,y,val);

    return 4 * pi * numerics::integrate(fu, 0, R, 0, R);
}

double PDEsolver::get_quadrupolar_mass_moment() const
{
    static std::vector<double> x(N*N), y(N*N), val(N*N);
    double l;
    #pragma omp parallel for schedule(static,1)
    for (size_t i = 0; i < N; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            x[i*N + j] = r(i);
            y[i*N + j] = z(j);
            l = sqrt(r(i)*r(i) + z(j)*z(j));
            val[i*N + j] =  r(i) * En(i,j) * l * l 
                                * (
                                     ( i > 0 || j > 0) ? 
                                     numerics::LegendreP2(z(j)/l)
                                      : 0
                                );
        }
    }
    _2D::BicubicInterpolator<double> fu;
    fu.setData(x,y,val);

    return 4 * pi * numerics::integrate(fu, 0, R, 0, R);
}


void  PDEsolver::update_B()
{
    //std::cout << "updtng B" << std::endl;
    //Interior
    for (size_t i = 1; i < N  - 1; i++)
    {
        for (size_t j = 1; j < N - 1 ; j++)
        {
            Br(i,j) = 1/r(i) * (Psi(i,j+1) - Psi(i,j-1)) / (2 * dx);
            Bz(i,j) = - 1/r(i) * (Psi(i + 1,j) - Psi(i - 1,j)) / (2 * dx);
        }

    }
    //Upper & lower boudaries
    for (size_t  i = 1; i < N - 1; i++)
    {
        Bz(i,N - 1) = - 1/r(i) * (Psi(i + 1,N - 1) - Psi(i - 1,N - 1)) / (2 * dx);
        Bz(i,0) = - 1/r(i) * (Psi(i + 1,0) - Psi(i - 1,0)) / (2 * dx);

        Br(i,0) =   0;
        Br(i,N-1) =  1/r(i) * (Psi(i,N-1) - Psi(i,N-2)) /   (z(N-1) - z(N-2));
    }
    //Update left boundary
    for (size_t j = 0; j < N; j++)
    {
        Br(0,j) = 0;
        Bz(0,j) = Bz(1,j);
    }

    //Update rigth boundary
    for (size_t j = 0; j < N; j++)
    {
        Bz(N-1,j) = -  1/r(N-1) * (Psi(N-1,j) - Psi(N-2,j)) /  dx;
        if (j == 0) Br(N-1,0) = 1/r(N-1) * (Psi(N-1,1) - Psi(N-1,0)) /  (z(1) - z(0));
        if (j == N -1 ) Br(N - 1, N - 1) = 1/r(N-1) *(Psi(N-1,N - 1) - Psi(N-1,N - 2)) /  (z(N-1) - z(N-2));
        if ( j > 0 && j < N - 1) Br(N-1,j) = 1/r(N-1) * (Psi(N-1,j+1) - Psi(N-1,j-1)) / (2 * dx);
    }

    
}





void PDEsolver::update_J()
{
    //std::cout << "updtng J" << std::endl;
    for (size_t i = 0; i < N; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            //double p = H(i,j) > 0 ? P(H(i,j),  sqrt(Br(i,j) * Br(i,j)+ Bz(i,j)*Bz(i,j))) : 0;
            J(i,j) = f0 * (Pr(i,j) + En(i,j));
        }
    }
}

void PDEsolver::update_M()
{
    //std::cout << "updtng M" << std::endl;
    for (size_t i = 0; i < N; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            Mag(i,j) = H(i,j) > 0 ? M(H(i,j),  sqrt(Br(i,j) * Br(i,j)+ Bz(i,j)*Bz(i,j))) : 0 ;
            
        }
    }
}


void PDEsolver::update_P()
{
    //std::cout << "updtng P" << std::endl;
    for (size_t i = 0; i < N; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            Pr(i,j) = H(i,j) > 0 ? P(H(i,j),  sqrt(Br(i,j) * Br(i,j)+ Bz(i,j)*Bz(i,j))) : 0 ;           
        }
    }
}



void PDEsolver::update_E()
{
    //std::cout << "updtng E" << std::endl;
    for (size_t i = 0; i < N; i++)
    {
        for (size_t j = 0; j < N; j++)
        {
            En(i,j) = H(i,j) > 0 ? E(H(i,j),  sqrt(Br(i,j) * Br(i,j)+ Bz(i,j)*Bz(i,j))) : 0 ;           
        }
    }
}




double PDEsolver::get_equatorial_radius() const
{
    size_t i;
    for (  i = 0; i < N-1; i++)
        if ( H(i+1, 0) <= 0) 
            break;
    return r(i+1);
}

double PDEsolver::get_polar_radius() const
{
    size_t i;
    for ( i = 0 ; i < N-1; i++)
        if ( H(0, i+1) <= 0) 
            break;
    return z(i+1);
}


double PDEsolver::get_polar_mf() const
{
    size_t i;
    for (i = 0 ; i < N-1; i++)
        if ( H(0, i+1) <= 0) 
            break;
    return Bz(0,i+1);
}

double PDEsolver::get_central_mf() const
{
    return Bz(0,0);
}


double PDEsolver::get_pressure_ratio() const
{
    double pper = Pr(0,0) - Mag(0,0) * Bz(0,0) + Bz(0,0)*Bz(0,0) / (8 * pi);
    double ppar = Pr(0,0) - Bz(0,0)*Bz(0,0) / (8 * pi);
    return ppar/pper;
}