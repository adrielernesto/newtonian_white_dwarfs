#include <PDEsolver.hpp>




void PDEsolver::solve(double Hc)
{
    double err = 1e+50;
    double tol = 1e-6;

    for (int k = 0; k < 14000; k++)
    {
        std::cout << "*";
        err = update_gs(Hc);

        if (err < tol) {
            printf("Converged :)\n");
            break;
        }

        /*
        std::ofstream file;
        file.open(".//out//Psi.dat");
        file << Psi;
        file.close();
        file.open(".//out//Br.dat");
        file << Br;
        file.close();
        file.open(".//out//Bz.dat");
        file << Bz;
        file.close();
        file.open(".//out//H.dat");
        file << H;
        file.close();
        */
        
       /*
        printf("Results from Poisson equation:\n");
        //printf("Mass:                %10.3f MS \n",get_mass()/MS);
        //printf("Magnetic energy:     %10.3e MS \n",get_magnetic_energy()/MS);
        printf("Equator radius:      %10.0f km \n",get_equatorial_radius()/km );
        printf("Rp/Rq:               %10.4f \n",get_polar_radius()/get_equatorial_radius());
        printf("Polar   Q:           %10.3e MS km^2\n",get_quadrupolar_mass_moment()/(MS * km * km) );
        printf("Polar mf:            %10.3e MeV^2 \n",get_polar_mf());
        printf("Central mf :         %10.3e MeV^2 \n",get_central_mf());
        printf("Pressure ratio :     %10.5f \n",get_pressure_ratio() );
        */
        
        printf("Error in U(0,0):     %10.3g \n",err );
        printf("\n");
        

    }
    if (err > tol) throw  "Did not converge :(\n";
    /*
    std::ofstream file;
        file.open(".//out//" + std::to_string(f0*1e+42) +"_"+ std::to_string(Hc*1000) + "_Psi.dat");
         file << Psi;
        file.close();
        file.open(".//out//" + std::to_string(f0*1e+42)  +"_"+ std::to_string(Hc*1000) + "_Br.dat");
        file << Br;
        file.close();
        file.open(".//out//" + std::to_string(f0*1e+42) +"_"+ std::to_string(Hc*1000) +  "_Bz.dat");
        file << Bz;
        file.close();
        file.open(".//out//" + std::to_string(f0*1e+42)  +"_"+ std::to_string(Hc*1000) + "_H.dat");
        file << H;
        file.close();
        file.open(".//out//" + std::to_string(f0*1e+42) +"_"+ std::to_string(Hc*1000) + "_M.dat");
        file << Mag;
        file.close();
        file.open(".//out//" + std::to_string(f0*1e+42) +"_"+ std::to_string(Hc*1000) + "_E.dat");
        file << En;
        file.close();
        file.open(".//out//" + std::to_string(f0*1e+42) +"_"+ std::to_string(Hc*1000)  + "_P.dat");
        file << Pr;
        file.close();

    */

        printf("Results from Poisson equation:\n");
        printf("Mass:                %10.3f MS \n",get_mass()/MS);
        printf("Magnetic energy:     %10.3e MS \n",get_magnetic_energy()/MS);
        printf("Equator radius:      %10.0f km \n",get_equatorial_radius()/km );
        printf("Rp/Rq:               %10.4f \n",get_polar_radius()/get_equatorial_radius());
        printf("Polar   Q:           %10.3e MS km^2\n",get_quadrupolar_mass_moment()/(MS * km * km) );
        printf("Polar mf:            %10.3e MeV^2 \n",get_polar_mf());
        printf("Central mf :         %10.3e MeV^2 \n",get_central_mf());
        printf("Pressure ratio :     %10.5f \n",get_pressure_ratio() );
}