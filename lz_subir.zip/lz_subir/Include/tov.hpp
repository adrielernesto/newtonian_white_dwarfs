#ifndef TOV_HPP

#define TOV_HPP

#include <Eigen/Dense>
#include <libInterpolate/Interpolate.hpp>
#include <vector>
#include <cstdio>

#include "numerics.hpp"


struct TOVsolution {
    function1D U_vs_r;
    function1D H_vs_r;
    double StarRadius;
    double StarMass;
};


TOVsolution solve_tov(double P0,function1D E, function1D H, double rmax, double h)
{
    printf("Solving spherical subproblem\n");

    auto f = [&](double r,  const  array & y, array & yf){
        double p = y(0) , m = y(1);
        double e = E(p);
        
        if (r < 0.01 * km)
        {
            yf(0)  =  - 4.0/3.0 * pi * G * e * e * r;
        }
        else
        {
            yf(0) = - G * e  * m/(r*r);
        }
         yf(1) = 4*pi*r*r*e;
    };

    double pmin = 0.0;
    double r = 0;
    double e0 = E(P0);
        
    double M = 0 * 4.0/3.0*pi*r*r*r*e0;

    array y(2) ;
    y(0) = P0; y(1) = M;
    array yf(2);
    array k1(2), k2(2), k3(2), k4(2);

    std::vector<double> r_vals;
    std::vector<double> u_vals;
    std::vector<double> h_vals;

    while (r < rmax)
    {
        r_vals.push_back(r);
        u_vals.push_back(-H(y(0)));
        h_vals.push_back(H(y(0)));
        //printf ("%.5f %.5e %.5f %.5e\n", r/km, y(0)/P0, y(1) / MS, H(y(0)));
        M = y(1); 

        f(r,y,k1);
        f(r + h /2, y + h / 2 * k1, k2);
        f(r + h /2, y + h / 2 * k2, k3);
        f(r + h , y + h * k3, k4);

        y += h/6 * (k1 + 2 * k2 + 2 * k3 + k4);
        r += h;

        if (y(0) <= pmin) break;     
    }

    double u_surface = - G * M / r;

    for (size_t i = 0; i < u_vals.size(); i++)
        u_vals[i]  += u_surface + h_vals.back();

    printf("done.\n");
    printf("Results from spherical guess:\n");
    printf("Mass:                %10.3g MS \n",M/MS);
    printf("Radius:              %10.0f km \n",r/km);
    printf("Surface u:           %10.3g \n",u_surface);
    printf("Surface H:           %10.3g \n\n",h_vals.back());

    _1D::CubicSplineInterpolator<double> u_interp, h_interp;

    u_interp.setData(r_vals,u_vals);
    h_interp.setData(r_vals,h_vals);

    return {
        u_interp,
        h_interp,
        r , M
    };

}




#endif