#ifndef EOS_HPP
#define EOS_HPP

#include <libInterpolate/Interpolate.hpp>
#include <fstream>
#include <vector>




namespace EoS {

    _2D::BicubicInterpolator<double> get_interpolator2D(const char* filenameE)
    {
        std::vector<double> H, B, E;
        std::ifstream fin(filenameE);

        double temp1, temp2, temp3;
        if (! fin.is_open()) throw "File for EoS not open";
        while (fin >> temp1 >> temp2 >> temp3)
        {
            H.push_back(temp1);
            B.push_back(temp2);
            E.push_back(temp3);
            //std::cout << temp1 << "\t" << temp2 << "\t" << temp3 << std::endl;
        }
        fin.close();

        _2D::BicubicInterpolator<double> interp;
        interp.setData(H,B,E);

        return interp;
    };

    _1D::CubicSplineInterpolator<double> get_interpolator1D(const char* filenameE)
    {
        std::vector<double> P, E;
        std::ifstream fin(filenameE);

        double temp1, temp2;
        if (! fin.is_open()) throw "File for EoS not open";
        while (fin >> temp1 >> temp2)
        {
            P.push_back(temp1);
            E.push_back(temp2);
            //std::cout << temp1 << "\t" << temp2 << "\t" << temp3 << std::endl;
        }
        fin.close();

        _1D::CubicSplineInterpolator<double> interp;
        interp.setData(P,E);

        return interp;
    }

};


#endif