clear 
rm GRHMS 
c++ -O3 -fopenmp -I ./Include/ main.cpp -o GRHMS 
./GRHMS 