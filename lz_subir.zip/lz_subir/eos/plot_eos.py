import matplotlib.pyplot as plt 
import pandas as pd  

dataP = pd.read_csv('PvsH_B.dat', delim_whitespace = True, header = None)
[x, y, z]  = data

N = int(len(x) * 0.5)
X_grid = x.values.reshape(N,N)
Y_grid = y.values.reshape(N,N)
Z_grid = z.values.reshape(N,N)
plt.contour(X_grid,Y_grid,Z_grid,levels=20)
plt.show()
